from flask import Flask, jsonify, request, render_template
import boto3
from boto3.dynamodb.conditions import Key
import time
import csv

app = Flask(__name__)

# Initialize DynamoDB local instance
dynamodb = boto3.resource(
    'dynamodb',
    endpoint_url='http://localhost:8000',  # Use DynamoDB Local
    region_name='us-west-2',              # You can use any region
    aws_access_key_id='dummy',
    aws_secret_access_key='dummy'
)

# Create or access the table
table_name = 'Users'
try:
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'UserId', 'KeyType': 'HASH'}  # Partition key
        ],
        AttributeDefinitions=[
            {'AttributeName': 'UserId', 'AttributeType': 'S'}
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        }
    )
    table.meta.client.get_waiter('table_exists').wait(TableName=table_name)
except dynamodb.meta.client.exceptions.ResourceInUseException:
    table = dynamodb.Table(table_name)

@app.route('/')
def index():
    """Redirects directly to the User Management Interface."""
    return render_template('frontend.html')

@app.route('/users', methods=['GET'])
def get_users():
    """Retrieve all users."""
    response = table.scan()
    return jsonify(response['Items'])

@app.route('/user', methods=['POST'])
def add_user():
    """Add a new user."""
    data = request.get_json()
    data['CreatedAt'] = int(time.time())  # Add timestamp
    table.put_item(Item=data)
    return jsonify({'message': 'User added successfully!'})

@app.route('/user/<user_id>', methods=['DELETE'])
def delete_user(user_id):
    """Delete a user."""
    table.delete_item(Key={'UserId': user_id})
    return jsonify({'message': 'User deleted successfully!'})

@app.route('/user/<user_id>', methods=['PUT'])
def update_user(user_id):
    """Update a user's details."""
    data = request.get_json()
    update_expression = "SET #name = :name, Email = :email"
    expression_attribute_values = {
        ':name': data['Name'],
        ':email': data['Email']
    }
    expression_attribute_names = {'#name': 'Name'}
    table.update_item(
        Key={'UserId': user_id},
        UpdateExpression=update_expression,
        ExpressionAttributeValues=expression_attribute_values,
        ExpressionAttributeNames=expression_attribute_names
    )
    return jsonify({'message': 'User updated successfully!'})

@app.route('/export', methods=['GET'])
def export_users():
    """Export user data to CSV."""
    response = table.scan()
    items = response['Items']
    csv_file = 'users.csv'
    with open(csv_file, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=['UserId', 'Name', 'Email', 'CreatedAt'])
        writer.writeheader()
        writer.writerows(items)
    return jsonify({'message': f'Data exported to {csv_file} successfully!'})

if __name__ == '__main__':
    app.run(debug=True)

